<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>addressbook</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>8c14a17c-7a19-4093-abd4-c2d2d787dc0c</testSuiteGuid>
   <testCaseLink>
      <guid>5312666f-7c09-4e41-82e6-2aa3b131c3ce</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/addressbook/login</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>4a8e46a0-0a70-47b1-811f-be6293e587e6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/addressbook/addGroup</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>4da2b0c9-c51e-4fea-ba45-bec1a0213089</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/addressbook/addContact</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>a41b9975-0968-44f0-a97e-87867164bae5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/addressbook/AddContact to the Group</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>0efaf01f-8f52-489d-9570-6f59ce41139c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/addressbook/DeleteContact</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>78374e0d-1438-4e8c-8a70-12bb6da95dcd</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/addressbook/Delete the Group</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>4c9ae459-5f25-47e8-a2e4-e627b2182c81</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/addressbook/logout</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    